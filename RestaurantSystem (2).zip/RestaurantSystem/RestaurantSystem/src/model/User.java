package model;

/**
 * Represents a generic user with a name and ID number.
 */
public class User {

    /**
     * Initializes variables for name and ID number.
     */
    protected String name;
    protected int IDNumber;

    /**
     * Constructs a user using the following parameters.
     * @param name of user
     * @param IDNumber of user
     */
    public User(String name, int IDNumber) {
        this.name = name;
        this.IDNumber = IDNumber;
    }

    /**
     * Gets the name of user selected.
     * @return name of user
     */
    public String getName() {
        return name;
    }

    /**
     * Gets ID number of user selected.
     * @return ID number of currently selected user
     */
    public int getIDNumber() {
        return IDNumber;
    }

    /**
     * Sets name to current user's name selected.
     * @param name of current user
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets IDNumber to current user's ID number.
     * @param IDNumber of current user selected
     */
    public void setIDNumber(int IDNumber) {
        this.IDNumber = IDNumber;
    }
}

